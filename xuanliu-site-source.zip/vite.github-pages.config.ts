import { fileURLToPath, URL } from "node:url";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const repositoryName = process.env.GITHUB_REPOSITORY?.split("/")[1];
const isGitHubPagesBuild = process.env.GITHUB_ACTIONS === "true";
const base = isGitHubPagesBuild && repositoryName ? `/${repositoryName}/` : "/";

/**
 * Browser-only build used by GitHub Pages. The production Sites build remains
 * in vite.config.ts because it also supports Workers/server features later.
 */
export default defineConfig({
  root: "github-pages",
  base,
  plugins: [react()],
  resolve: {
    alias: {
      "next/dynamic": fileURLToPath(new URL("./github-pages/next-dynamic.tsx", import.meta.url)),
    },
  },
  build: {
    outDir: "../docs",
    emptyOutDir: true,
  },
});
