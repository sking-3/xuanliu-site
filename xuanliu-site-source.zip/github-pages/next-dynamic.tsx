import { lazy, Suspense, type ComponentType } from "react";

type DynamicLoader<Props extends object> = () => Promise<{
  default: ComponentType<Props>;
}>;

/**
 * Small browser-only replacement for next/dynamic.
 * The main experience is already a client component, so GitHub Pages only
 * needs lazy loading and a neutral loading boundary.
 */
export default function dynamic<Props extends object>(loader: DynamicLoader<Props>) {
  const DynamicComponent = lazy(loader);

  return function DynamicClientComponent(props: Props) {
    return (
      <Suspense fallback={null}>
        <DynamicComponent {...props} />
      </Suspense>
    );
  };
}
