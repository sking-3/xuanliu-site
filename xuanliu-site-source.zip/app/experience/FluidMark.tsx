"use client";

import {
  useEffect,
  useRef,
  type CSSProperties,
  type RefObject,
} from "react";

/**
 * Viewport-normalized pointer data. `x` and `y` are in the -1..1 range;
 * positive `y` points upward. `speed` and `down` are eased 0..1 intensities.
 */
export type FluidMarkPointer = {
  x: number;
  y: number;
  speed: number;
  down: number;
};

export type FluidMarkProps = {
  pointerRef: RefObject<FluidMarkPointer>;
  className?: string;
  style?: CSSProperties;
};

const RESTING_STYLE: CSSProperties = {
  display: "block",
  width: "100%",
  height: 22,
  pointerEvents: "none",
};

const POSITION_BEND_X = 0;
const POSITION_BEND_Y = 1;
const POSITION_STRETCH = 2;
const POSITION_TWIST = 3;
const POSITION_ENERGY = 4;
const POSITION_COUNT = 5;

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

const finiteOr = (value: number, fallback = 0) =>
  Number.isFinite(value) ? value : fallback;

const smoothstep = (edge0: number, edge1: number, value: number) => {
  const amount = clamp((value - edge0) / (edge1 - edge0), 0, 1);
  return amount * amount * (3 - 2 * amount);
};

type RibbonOptions = {
  offset: number;
  phase: number;
  thickness: number;
  opacity: number;
  bendScale: number;
  highlight: boolean;
};

function drawRibbon(
  context: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number,
  positions: Float32Array,
  options: RibbonOptions,
) {
  const bendX = positions[POSITION_BEND_X];
  const bendY = positions[POSITION_BEND_Y] * options.bendScale;
  const stretch = positions[POSITION_STRETCH];
  const twist = positions[POSITION_TWIST];
  const energy = positions[POSITION_ENERGY];
  const centerY = height * (0.5 + options.offset);
  const breathing = Math.sin(time * 1.08 + options.phase) * height * 0.025;
  const tremor = Math.sin(time * 2.1 + options.phase * 1.7) * height * 0.012 * energy;
  const restingWave = Math.cos(options.phase * 1.7 + 0.34) * height * 0.15;
  const startX = width * (0.075 - stretch * 0.024);
  const endX = width * (0.925 + stretch * 0.024);
  const endY = centerY - bendY * 0.09 + breathing * 0.35;
  const controlOneX = width * (0.31 - stretch * 0.055) + bendX * 0.16;
  const controlTwoX = width * (0.67 + stretch * 0.07) + bendX * 0.82;
  const controlOneY = centerY + bendY * 0.38 + breathing + tremor - restingWave;
  const controlTwoY = centerY + bendY + breathing * 0.52 - tremor + restingWave + twist * height * 0.1;
  const bodyWidth = options.thickness * (1 + energy * 0.38);
  const firstWidth = bodyWidth * 0.56;
  const secondWidth = bodyWidth * 0.92;

  const gradient = context.createLinearGradient(startX, centerY, endX, endY);
  gradient.addColorStop(0, "rgba(125, 185, 168, 0)");
  gradient.addColorStop(0.13, `rgba(140, 199, 181, ${0.3 * options.opacity})`);
  gradient.addColorStop(0.37, `rgba(207, 231, 222, ${0.74 * options.opacity})`);
  gradient.addColorStop(0.57, `rgba(247, 247, 237, ${0.96 * options.opacity})`);
  gradient.addColorStop(0.76, `rgba(174, 217, 201, ${0.61 * options.opacity})`);
  gradient.addColorStop(1, "rgba(105, 174, 154, 0)");

  context.beginPath();
  context.moveTo(startX, centerY);
  context.bezierCurveTo(
    controlOneX,
    controlOneY - firstWidth,
    controlTwoX,
    controlTwoY - secondWidth,
    endX,
    endY,
  );
  context.bezierCurveTo(
    controlTwoX,
    controlTwoY + secondWidth,
    controlOneX,
    controlOneY + firstWidth,
    startX,
    centerY,
  );
  context.closePath();
  context.fillStyle = gradient;
  context.shadowColor = `rgba(137, 217, 191, ${0.32 * options.opacity})`;
  context.shadowBlur = bodyWidth * (2.5 + energy * 2.2);
  context.fill();

  if (!options.highlight) return;

  const highlight = context.createLinearGradient(startX, 0, endX, 0);
  highlight.addColorStop(0, "rgba(255, 255, 248, 0)");
  highlight.addColorStop(0.29, "rgba(230, 246, 238, 0.2)");
  highlight.addColorStop(0.53, "rgba(255, 255, 250, 0.86)");
  highlight.addColorStop(0.77, "rgba(210, 241, 228, 0.24)");
  highlight.addColorStop(1, "rgba(255, 255, 248, 0)");
  context.beginPath();
  context.moveTo(startX, centerY - bodyWidth * 0.12);
  context.bezierCurveTo(
    controlOneX,
    controlOneY - bodyWidth * 0.38,
    controlTwoX,
    controlTwoY - bodyWidth * 0.52,
    endX,
    endY,
  );
  context.strokeStyle = highlight;
  context.lineWidth = Math.max(0.45, bodyWidth * 0.19);
  context.shadowColor = "rgba(220, 255, 242, 0.55)";
  context.shadowBlur = bodyWidth * 1.4;
  context.stroke();
}

function drawMark(
  context: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number,
  positions: Float32Array,
) {
  context.clearRect(0, 0, width, height);
  context.save();
  context.globalCompositeOperation = "lighter";

  drawRibbon(context, width, height, time, positions, {
    offset: 0.09,
    phase: 4.4,
    thickness: height * 0.075,
    opacity: 0.34,
    bendScale: 0.72,
    highlight: false,
  });
  drawRibbon(context, width, height, time, positions, {
    offset: -0.09,
    phase: 1.8,
    thickness: height * 0.086,
    opacity: 0.43,
    bendScale: 1.12,
    highlight: false,
  });
  drawRibbon(context, width, height, time, positions, {
    offset: 0,
    phase: 0,
    thickness: height * 0.16,
    opacity: 0.95,
    bendScale: 1,
    highlight: true,
  });

  context.restore();
}

export default function FluidMark({
  pointerRef,
  className,
  style,
}: FluidMarkProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext("2d", {
      alpha: true,
      desynchronized: true,
    });
    if (!context) return;

    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const positions = new Float32Array(POSITION_COUNT);
    const velocities = new Float32Array(POSITION_COUNT);
    const targets = new Float32Array(POSITION_COUNT);
    let logicalWidth = 1;
    let logicalHeight = 1;
    let cachedBounds = canvas.getBoundingClientRect();
    let animationFrame = 0;
    let elapsed = 0;
    let previousTime = performance.now();
    let reducedMotion = motionQuery.matches;
    let visible = !document.hidden;

    const resizeCanvas = () => {
      const bounds = canvas.getBoundingClientRect();
      cachedBounds = bounds;
      logicalWidth = Math.max(1, bounds.width);
      logicalHeight = Math.max(1, bounds.height);
      const pixelRatio = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
      const pixelWidth = Math.max(1, Math.round(logicalWidth * pixelRatio));
      const pixelHeight = Math.max(1, Math.round(logicalHeight * pixelRatio));

      if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
        canvas.width = pixelWidth;
        canvas.height = pixelHeight;
      }
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);

      if (reducedMotion || animationFrame === 0) {
        drawMark(context, logicalWidth, logicalHeight, reducedMotion ? 0 : elapsed, positions);
      }
    };

    const updateTargets = () => {
      const pointer = pointerRef.current;
      if (!pointer) {
        targets.fill(0);
        return;
      }

      const pointerX = (clamp(finiteOr(pointer.x), -1, 1) + 1) * window.innerWidth * 0.5;
      const pointerY = (1 - clamp(finiteOr(pointer.y), -1, 1)) * window.innerHeight * 0.5;
      const bounds = cachedBounds;
      const deltaX = pointerX - (bounds.left + bounds.width * 0.5);
      const deltaY = pointerY - (bounds.top + bounds.height * 0.5);
      const distance = Math.hypot(deltaX, deltaY);
      const interactionRadius = Math.max(150, logicalWidth * 3.5);
      const proximity = 1 - smoothstep(logicalWidth * 0.65, interactionRadius, distance);
      const speedEnergy = clamp(Math.abs(finiteOr(pointer.speed)), 0, 1);
      const pressed = clamp(finiteOr(pointer.down), 0, 1);
      const horizontalDirection = clamp(deltaX / interactionRadius, -1, 1);
      const verticalDirection = clamp(deltaY / interactionRadius, -1, 1);

      targets[POSITION_BEND_X] = horizontalDirection * logicalWidth * 0.24 * proximity;
      targets[POSITION_BEND_Y] = verticalDirection * logicalHeight * 0.92 * proximity;
      targets[POSITION_STRETCH] = proximity * (0.22 + speedEnergy * 0.48 + pressed * 0.24);
      targets[POSITION_TWIST] = proximity * (horizontalDirection * 0.74 - verticalDirection * pressed * 0.24);
      targets[POSITION_ENERGY] = proximity * (0.16 + speedEnergy * 0.78 + pressed * 0.28);
    };

    const updateSprings = (delta: number) => {
      updateTargets();
      const stiffness = 116;
      const damping = 17.5;

      for (let index = 0; index < POSITION_COUNT; index += 1) {
        const acceleration =
          (targets[index] - positions[index]) * stiffness - velocities[index] * damping;
        velocities[index] += acceleration * delta;
        positions[index] += velocities[index] * delta;
      }
    };

    const render = (now: number) => {
      animationFrame = 0;
      if (!visible || reducedMotion) return;

      const delta = clamp((now - previousTime) / 1000, 0.001, 0.034);
      previousTime = now;
      elapsed += delta;
      updateSprings(delta);
      drawMark(context, logicalWidth, logicalHeight, elapsed, positions);
      animationFrame = window.requestAnimationFrame(render);
    };

    const startAnimation = () => {
      if (!visible || reducedMotion || animationFrame !== 0) return;
      previousTime = performance.now();
      animationFrame = window.requestAnimationFrame(render);
    };

    const stopAnimation = () => {
      if (animationFrame === 0) return;
      window.cancelAnimationFrame(animationFrame);
      animationFrame = 0;
    };

    const handleVisibility = () => {
      visible = !document.hidden;
      if (visible) startAnimation();
      else stopAnimation();
    };

    const handleMotionPreference = (event: MediaQueryListEvent) => {
      reducedMotion = event.matches;
      if (reducedMotion) {
        stopAnimation();
        positions.fill(0);
        velocities.fill(0);
        targets.fill(0);
        drawMark(context, logicalWidth, logicalHeight, 0, positions);
      } else {
        startAnimation();
      }
    };

    const resizeObserver =
      typeof ResizeObserver === "undefined" ? null : new ResizeObserver(resizeCanvas);

    resizeCanvas();
    resizeObserver?.observe(canvas);
    window.addEventListener("resize", resizeCanvas, { passive: true });
    document.addEventListener("visibilitychange", handleVisibility, { passive: true });
    motionQuery.addEventListener("change", handleMotionPreference);

    if (reducedMotion) drawMark(context, logicalWidth, logicalHeight, 0, positions);
    else startAnimation();

    return () => {
      stopAnimation();
      resizeObserver?.disconnect();
      window.removeEventListener("resize", resizeCanvas);
      document.removeEventListener("visibilitychange", handleVisibility);
      motionQuery.removeEventListener("change", handleMotionPreference);
    };
  }, [pointerRef]);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      aria-hidden="true"
      style={{ ...RESTING_STYLE, ...style }}
    />
  );
}
