"use client";

import { useEffect, useRef, type MutableRefObject } from "react";
import type { InkPointer } from "./InkCanvas";

interface WuxingSigilProps {
  progressRef: MutableRefObject<number>;
  pointerRef: MutableRefObject<InkPointer>;
}

const elementColors = ["#6f9877", "#a95b4b", "#b69a67", "#c8cec4", "#557d91"];

function clamp(value: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function smoothstep(edge0: number, edge1: number, value: number) {
  const amount = clamp((value - edge0) / Math.max(0.0001, edge1 - edge0));
  return amount * amount * (3 - 2 * amount);
}

function hash(index: number, salt = 0) {
  const value = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

function pointOnCubic(
  start: readonly [number, number],
  controlA: readonly [number, number],
  controlB: readonly [number, number],
  end: readonly [number, number],
  amount: number,
) {
  const inverse = 1 - amount;
  const a = inverse * inverse * inverse;
  const b = 3 * inverse * inverse * amount;
  const c = 3 * inverse * amount * amount;
  const d = amount * amount * amount;
  return [
    start[0] * a + controlA[0] * b + controlB[0] * c + end[0] * d,
    start[1] * a + controlA[1] * b + controlB[1] * c + end[1] * d,
  ] as const;
}

function drawInkDot(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  opacity: number,
  color = "154,190,171",
) {
  const gradient = context.createRadialGradient(x, y, 0, x, y, Math.max(0.5, radius));
  gradient.addColorStop(0, `rgba(${color},${opacity})`);
  gradient.addColorStop(0.48, `rgba(${color},${opacity * 0.42})`);
  gradient.addColorStop(1, `rgba(${color},0)`);
  context.fillStyle = gradient;
  context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
}

function drawInkStroke(
  context: CanvasRenderingContext2D,
  points: [[number, number], [number, number], [number, number], [number, number]],
  width: number,
  opacity: number,
  elapsed: number,
  salt: number,
) {
  const steps = 72;
  for (let index = 0; index <= steps; index += 1) {
    const amount = index / steps;
    const [x, y] = pointOnCubic(points[0], points[1], points[2], points[3], amount);
    const taper = Math.sin(Math.PI * clamp(amount * 1.08)) * (0.62 + hash(index, salt) * 0.48);
    const jitter = (hash(index, salt + 13) - 0.5) * width * 0.34;
    const breathing = 0.9 + Math.sin(elapsed * 0.58 + index * 0.16) * 0.1;
    drawInkDot(
      context,
      x + jitter,
      y + (hash(index, salt + 29) - 0.5) * width * 0.2,
      Math.max(1, width * taper * breathing),
      opacity * (0.12 + hash(index, salt + 41) * 0.25),
    );
  }
}

function drawQinTrace(
  context: CanvasRenderingContext2D,
  width: number,
  height: number,
  opacity: number,
  elapsed: number,
  driftX: number,
  driftY: number,
) {
  const crownX = width * 0.505 + driftX;
  const crownY = height * 0.325 + driftY;
  const handX = width * (width < 700 ? 0.7 : 0.665) + driftX;
  const handY = height * (width < 700 ? 0.665 : 0.69) + driftY;
  const scale = Math.max(0.74, Math.min(width / 1600, height / 900));

  context.save();
  context.globalCompositeOperation = "screen";

  // The emperor is never fully shown: only a Qin crown trace, a sleeve and a hand.
  drawInkStroke(context, [
    [crownX - width * 0.052, crownY],
    [crownX - width * 0.018, crownY - height * 0.012],
    [crownX + width * 0.018, crownY + height * 0.01],
    [crownX + width * 0.052, crownY],
  ], 4.2 * scale, opacity * 0.82, elapsed, 7);

  for (let bead = -4; bead <= 4; bead += 1) {
    const beadX = crownX + bead * width * 0.011;
    const length = height * (0.034 + Math.abs(bead % 2) * 0.008);
    const sway = Math.sin(elapsed * 0.42 + bead) * width * 0.0018;
    drawInkStroke(context, [
      [beadX, crownY],
      [beadX + sway, crownY + length * 0.33],
      [beadX - sway, crownY + length * 0.7],
      [beadX + sway * 0.5, crownY + length],
    ], 1.8 * scale, opacity * 0.43, elapsed, 23 + bead);
  }

  drawInkStroke(context, [
    [width * 0.545 + driftX, height * 0.47 + driftY],
    [width * 0.585 + driftX, height * 0.5 + driftY],
    [width * 0.61 + driftX, height * 0.61 + driftY],
    [handX, handY - height * 0.02],
  ], 17 * scale, opacity * 0.92, elapsed, 71);

  for (let palm = 0; palm < 34; palm += 1) {
    const angle = hash(palm, 9) * Math.PI * 2;
    const radius = Math.sqrt(hash(palm, 17)) * width * 0.016;
    drawInkDot(
      context,
      handX + Math.cos(angle) * radius,
      handY + Math.sin(angle) * radius * 0.72,
      (2.4 + hash(palm, 31) * 5.4) * scale,
      opacity * (0.08 + hash(palm, 43) * 0.2),
    );
  }

  for (let finger = 0; finger < 5; finger += 1) {
    const offset = (finger - 2) * width * 0.0062;
    drawInkStroke(context, [
      [handX + offset, handY + height * 0.006],
      [handX + offset * 1.04, handY + height * 0.027],
      [handX + offset * 1.12, handY + height * 0.048],
      [handX + offset * 1.08, handY + height * (0.062 - Math.abs(finger - 2) * 0.004)],
    ], 2.25 * scale, opacity * (0.58 - Math.abs(finger - 2) * 0.06), elapsed, 89 + finger);
  }

  context.restore();
  return { handX, handY };
}

function drawWujiOrb(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  opacity: number,
  elapsed: number,
) {
  const pulse = 0.94 + Math.sin(elapsed * 1.22) * 0.06;
  const aura = context.createRadialGradient(x, y, 0, x, y, radius * 3.4);
  aura.addColorStop(0, `rgba(202,230,214,${opacity * 0.3})`);
  aura.addColorStop(0.18, `rgba(94,154,127,${opacity * 0.18})`);
  aura.addColorStop(0.56, `rgba(48,94,76,${opacity * 0.08})`);
  aura.addColorStop(1, "rgba(0,0,0,0)");
  context.fillStyle = aura;
  context.fillRect(x - radius * 3.4, y - radius * 3.4, radius * 6.8, radius * 6.8);

  for (let index = 0; index < 96; index += 1) {
    const angle = hash(index, 113) * Math.PI * 2 + elapsed * 0.025;
    const distance = Math.pow(hash(index, 127), 0.7) * radius * pulse;
    drawInkDot(
      context,
      x + Math.cos(angle) * distance,
      y + Math.sin(angle) * distance,
      radius * (0.05 + hash(index, 151) * 0.15),
      opacity * (0.12 + hash(index, 167) * 0.34),
      index % 3 === 0 ? "217,231,217" : "97,145,122",
    );
  }
}

function particleTaiji(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  opacity: number,
  elapsed: number,
) {
  const rotation = elapsed * 0.09 - 0.26;
  context.save();
  context.globalCompositeOperation = "screen";
  context.translate(x, y);
  context.rotate(rotation);

  for (let index = 0; index < 112; index += 1) {
    const angle = index / 112 * Math.PI * 2;
    const jitter = (hash(index, 181) - 0.5) * radius * 0.045;
    drawInkDot(
      context,
      Math.cos(angle) * (radius + jitter),
      Math.sin(angle) * (radius + jitter),
      radius * (0.025 + hash(index, 183) * 0.035),
      opacity * (0.22 + hash(index, 187) * 0.28),
      "214,234,221",
    );
  }

  const separatorSegments = [
    [[0, -radius], [radius * 0.72, -radius * 0.72], [radius * 0.72, -radius * 0.28], [0, 0]],
    [[0, 0], [-radius * 0.72, radius * 0.28], [-radius * 0.72, radius * 0.72], [0, radius]],
  ] as const;
  separatorSegments.forEach((segment, segmentIndex) => {
    for (let index = 0; index <= 46; index += 1) {
      const [dotX, dotY] = pointOnCubic(segment[0], segment[1], segment[2], segment[3], index / 46);
      drawInkDot(context, dotX, dotY, radius * (0.025 + hash(index, 241 + segmentIndex) * 0.035), opacity * 0.35, "216,235,222");
    }
  });

  drawInkDot(context, 0, -radius * 0.5, radius * 0.105, opacity * 0.72, "213,234,220");
  drawInkDot(context, 0, radius * 0.5, radius * 0.105, opacity * 0.45, "92,147,122");

  for (let index = 0; index < 260; index += 1) {
    const angle = hash(index, 191) * Math.PI * 2;
    const radial = Math.sqrt(hash(index, 211));
    const localX = Math.cos(angle) * radial;
    const localY = Math.sin(angle) * radial;
    const separator = Math.sin(localY * Math.PI) * 0.42;
    const isLight = localX > separator;
    const eyeA = Math.hypot(localX - 0.16, localY + 0.49);
    const eyeB = Math.hypot(localX + 0.16, localY - 0.49);
    const light = eyeA < 0.12 ? false : eyeB < 0.12 ? true : isLight;
    const rotatedX = localX * radius;
    const rotatedY = localY * radius;
    const fringe = 1 - smoothstep(0.86, 1, radial);
    drawInkDot(
      context,
      rotatedX + (hash(index, 223) - 0.5) * radius * 0.05,
      rotatedY + (hash(index, 227) - 0.5) * radius * 0.05,
      radius * (0.018 + hash(index, 229) * 0.052),
      opacity * fringe * (0.13 + hash(index, 233) * 0.34),
      light ? "222,235,222" : "60,103,87",
    );
  }
  context.restore();
}

export default function WuxingSigil({ progressRef, pointerRef }: WuxingSigilProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: true, desynchronized: true });
    if (!context) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let frameId = 0;
    let previousDraw = 0;
    let logicalWidth = 1;
    let logicalHeight = 1;
    const startedAt = performance.now();

    const resize = () => {
      const bounds = canvas.getBoundingClientRect();
      logicalWidth = Math.max(1, bounds.width);
      logicalHeight = Math.max(1, bounds.height);
      const pixelRatio = Math.min(1.25, window.devicePixelRatio || 1);
      canvas.width = Math.round(logicalWidth * pixelRatio);
      canvas.height = Math.round(logicalHeight * pixelRatio);
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    };

    const render = (now: number) => {
      frameId = window.requestAnimationFrame(render);
      const frameInterval = reducedMotion ? 90 : pointerRef.current.speed > 0.04 ? 24 : 34;
      if (now - previousDraw < frameInterval) return;
      previousDraw = now;
      const elapsed = reducedMotion ? 0 : (now - startedAt) / 1000;
      const progress = progressRef.current;
      const reveal = smoothstep(0.83, 0.895, progress);
      const dissolve = 1 - smoothstep(0.985, 1, progress);
      const traceOpacity = reveal * dissolve;
      const orbOpacity = smoothstep(0.82, 0.88, progress) * (1 - smoothstep(0.94, 0.985, progress));
      const taijiOpacity = smoothstep(0.865, 0.92, progress) * dissolve;
      const pointer = pointerRef.current;
      const driftX = pointer.x * logicalWidth * 0.004 * reveal;
      const driftY = -pointer.y * logicalHeight * 0.004 * reveal;
      const handTargetX = 0.33;
      const handTargetY = -0.38;
      const pointerNearHand = clamp(1 - Math.hypot(pointer.x - handTargetX, pointer.y - handTargetY) / 0.72);
      const interactionBoost = 0.96 + pointerNearHand * 0.38 + pointer.speed * 0.16;
      const baseSize = Math.min(logicalWidth, logicalHeight);
      context.clearRect(0, 0, logicalWidth, logicalHeight);

      drawWujiOrb(
        context,
        logicalWidth * 0.5 + driftX,
        logicalHeight * 0.485 + driftY,
        baseSize * 0.043,
        orbOpacity,
        elapsed,
      );

      if (traceOpacity > 0.002) {
        const { handX, handY } = drawQinTrace(
          context,
          logicalWidth,
          logicalHeight,
          traceOpacity * interactionBoost,
          elapsed,
          driftX,
          driftY,
        );
        particleTaiji(
          context,
          handX,
          handY + baseSize * 0.014,
          baseSize * 0.061,
          taijiOpacity * interactionBoost * 1.18,
          elapsed,
        );

        for (let index = 0; index < elementColors.length; index += 1) {
          const angle = -Math.PI / 2 + index / elementColors.length * Math.PI * 2 + elapsed * 0.1;
          const orbit = baseSize * 0.09;
          const x = handX + Math.cos(angle) * orbit;
          const y = handY + Math.sin(angle) * orbit * 0.72;
          const color = elementColors[index].slice(1);
          const red = Number.parseInt(color.slice(0, 2), 16);
          const green = Number.parseInt(color.slice(2, 4), 16);
          const blue = Number.parseInt(color.slice(4, 6), 16);
          drawInkDot(context, x, y, baseSize * 0.009, taijiOpacity * 0.34, `${red},${green},${blue}`);
        }
      }
    };

    resize();
    window.addEventListener("resize", resize, { passive: true });
    frameId = window.requestAnimationFrame(render);
    return () => {
      window.cancelAnimationFrame(frameId);
      window.removeEventListener("resize", resize);
    };
  }, [pointerRef, progressRef]);

  return <canvas ref={canvasRef} className="wuxing-sigil" aria-hidden="true" />;
}
