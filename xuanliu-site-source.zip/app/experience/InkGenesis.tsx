"use client";

import { useEffect, useRef, useState } from "react";

interface InkGenesisProps {
  onComplete: () => void;
}

interface InkField {
  width: number;
  height: number;
  density: Float32Array;
  next: Float32Array;
  pixels: ImageData;
  canvas: HTMLCanvasElement;
  context: CanvasRenderingContext2D;
}

const duration = 6.65;

function clamp(value: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function smoothstep(edge0: number, edge1: number, value: number) {
  const amount = clamp((value - edge0) / Math.max(0.0001, edge1 - edge0));
  return amount * amount * (3 - 2 * amount);
}

function hash(x: number, y: number) {
  const value = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

function createInkField(viewportWidth: number, viewportHeight: number): InkField {
  const shortest = Math.min(viewportWidth, viewportHeight);
  const quality = viewportWidth < 700 ? 142 : shortest < 900 ? 174 : 204;
  const width = Math.max(96, Math.round(quality * viewportWidth / viewportHeight));
  const height = quality;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { alpha: true });
  if (!context) throw new Error("Ink diffusion canvas is unavailable");
  return {
    width,
    height,
    density: new Float32Array(width * height),
    next: new Float32Array(width * height),
    pixels: context.createImageData(width, height),
    canvas,
    context,
  };
}

function sample(field: InkField, x: number, y: number) {
  const x0 = Math.max(0, Math.min(field.width - 1, Math.floor(x)));
  const y0 = Math.max(0, Math.min(field.height - 1, Math.floor(y)));
  const x1 = Math.min(field.width - 1, x0 + 1);
  const y1 = Math.min(field.height - 1, y0 + 1);
  const tx = clamp(x - x0);
  const ty = clamp(y - y0);
  const a = field.density[y0 * field.width + x0];
  const b = field.density[y0 * field.width + x1];
  const c = field.density[y1 * field.width + x0];
  const d = field.density[y1 * field.width + x1];
  return (a + (b - a) * tx) + ((c + (d - c) * tx) - (a + (b - a) * tx)) * ty;
}

function taijiDensity(x: number, y: number, time: number) {
  const rotation = -0.34 + time * 0.025;
  const cosine = Math.cos(rotation);
  const sine = Math.sin(rotation);
  const px = x * cosine - y * sine;
  const py = x * sine + y * cosine;
  const radius = 0.305;
  const distance = Math.hypot(px, py);
  if (distance > radius) return 0;

  const feather = 1 - smoothstep(radius * 0.91, radius, distance);
  const separator = Math.sin((py / radius) * Math.PI) * radius * 0.245;
  let density = px > separator ? 0.9 : 0.18;
  const upperEye = Math.hypot(px - radius * 0.12, py + radius * 0.49);
  const lowerEye = Math.hypot(px + radius * 0.12, py - radius * 0.49);
  if (upperEye < radius * 0.095) density = 0.12;
  if (lowerEye < radius * 0.095) density = 0.94;

  const paperNoise = (hash(Math.floor(px * 760), Math.floor(py * 760)) - 0.5) * 0.13;
  return clamp((density + paperNoise) * feather);
}

function stepInk(field: InkField, elapsed: number, delta: number) {
  const { width, height, density, next } = field;
  const centerX = width * 0.5;
  const centerY = height * 0.49;
  const shortest = Math.min(width, height);
  const impact = 1 - smoothstep(1.18, 2.35, elapsed);
  const reveal = smoothstep(2.65, 5.45, elapsed);
  const timeScale = Math.min(1.5, Math.max(0.38, delta * 60));

  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const index = y * width + x;
      const dx = (x - centerX) / shortest;
      const dy = (y - centerY) / shortest;
      const radius = Math.hypot(dx, dy) + 0.0001;
      const radialEnergy = Math.exp(-radius * radius * 34) * impact;
      const curlNoise = Math.sin(dx * 23 + elapsed * 0.7) * Math.cos(dy * 19 - elapsed * 0.43);

      const lobe = dy < 0 ? -1 : 1;
      const vortexX = centerX + lobe * shortest * 0.055;
      const vortexY = centerY + lobe * shortest * 0.12;
      const vx = x - vortexX;
      const vy = y - vortexY;
      const vortexDistance = Math.max(5, Math.hypot(vx, vy));
      const vortexStrength = (0.08 + reveal * 0.34) * Math.exp(-vortexDistance / (shortest * 0.34));

      const velocityX = dx / radius * radialEnergy * 1.8
        - vy / vortexDistance * vortexStrength * lobe
        + curlNoise * 0.035;
      const velocityY = dy / radius * radialEnergy * 1.2
        + vx / vortexDistance * vortexStrength * lobe
        + Math.sin(dx * 31 - elapsed) * 0.018;
      const advected = sample(field, x - velocityX * timeScale, y - velocityY * timeScale);
      const neighbor = (
        density[index - 1]
        + density[index + 1]
        + density[index - width]
        + density[index + width]
      ) * 0.25;

      const injectionDistance = Math.hypot(x - centerX, (y - centerY) * 1.16) / shortest;
      const injection = elapsed < 1.86
        ? Math.exp(-injectionDistance * injectionDistance * 1200) * smoothstep(1.12, 1.28, elapsed) * 1.85
        : 0;
      const target = taijiDensity(dx, dy, elapsed);
      const targetPull = reveal * reveal * (0.018 + reveal * 0.042);
      next[index] = clamp(
        (advected * 0.945 + neighbor * 0.052 + injection) * 0.998
        + (target - advected) * targetPull,
      );
    }
  }

  field.density = next;
  field.next = density;
}

function renderInkField(
  context: CanvasRenderingContext2D,
  field: InkField,
  width: number,
  height: number,
  elapsed: number,
  reducedMotion: boolean,
) {
  const reveal = reducedMotion ? 1 : smoothstep(0.94, 1.56, elapsed);
  const pixels = field.pixels.data;
  const shortest = Math.min(field.width, field.height);
  const centerX = field.width * 0.5;
  const centerY = field.height * 0.49;

  for (let y = 0; y < field.height; y += 1) {
    for (let x = 0; x < field.width; x += 1) {
      const index = y * field.width + x;
      const pixelIndex = index * 4;
      const dx = (x - centerX) / shortest;
      const dy = (y - centerY) / shortest;
      const impactAge = Math.max(0, elapsed - 1.04);
      const radius = Math.hypot(dx, dy);
      const angle = Math.atan2(dy, dx);
      const bloomRadius = 0.015 + smoothstep(0, 2.4, impactAge) * 0.245;
      const unevenEdge = bloomRadius * (0.82 + Math.sin(angle * 5 + elapsed * 0.6) * 0.08 + (hash(x, y) - 0.5) * 0.16);
      const coarseGrain = hash(Math.floor(x / 3), Math.floor(y / 3));
      const core = Math.exp(-Math.pow(radius / Math.max(0.008, unevenEdge), 2) * 1.18)
        * (0.7 + coarseGrain * 0.44);
      const tendrils = Math.exp(-radius / Math.max(0.008, bloomRadius * 1.36))
        * Math.pow(Math.max(0, Math.sin(angle * 7 - elapsed * 0.72) * 0.5 + 0.5), 5)
        * (0.16 + hash(Math.floor(x / 5), Math.floor(y / 5)) * 0.38);
      const bloom = impactAge > 0
        ? clamp(Math.max(core, tendrils) * (1 - smoothstep(2.55, 4.8, impactAge)))
        : 0;
      const direct = reducedMotion ? taijiDensity(dx, dy, elapsed) : Math.max(field.density[index], bloom);
      const density = Math.pow(clamp(direct), 0.72);
      const mineral = hash(x * 3, y * 5) * 9;
      const value = Math.round(clamp(255 - density * (246 + mineral), 0, 255));
      pixels[pixelIndex] = value;
      pixels[pixelIndex + 1] = value;
      pixels[pixelIndex + 2] = value;
      pixels[pixelIndex + 3] = Math.round(255 * reveal);
    }
  }

  field.context.putImageData(field.pixels, 0, 0);
  context.save();
  context.imageSmoothingEnabled = true;
  context.filter = `blur(${1.1 + reveal * 0.8}px) contrast(${1.04 + reveal * 0.12})`;
  context.globalAlpha = reveal;
  context.drawImage(field.canvas, 0, 0, width, height);
  context.restore();

  context.save();
  context.globalCompositeOperation = "multiply";
  for (let index = 0; index < 160; index += 1) {
    const x = hash(index, 17) * width;
    const y = hash(index, 41) * height;
    const alpha = hash(index, 93) * 0.055 * reveal;
    const radius = 0.35 + hash(index, 71) * 1.7;
    context.beginPath();
    context.arc(x, y, radius, 0, Math.PI * 2);
    context.fillStyle = `rgba(0,0,0,${alpha})`;
    context.fill();
  }
  context.restore();
}

function drawDroplet(
  context: CanvasRenderingContext2D,
  centerX: number,
  centerY: number,
  scale: number,
  elapsed: number,
) {
  const fall = smoothstep(0.22, 1.15, elapsed);
  if (fall <= 0 || fall >= 1) return;
  const y = -34 * scale + (centerY + 1 * scale) * fall;
  const radius = 8 * scale;
  const stretch = 1 + Math.sin(fall * Math.PI) * 0.65;
  context.save();
  context.translate(centerX, y);
  context.scale(0.76, stretch);
  context.beginPath();
  context.moveTo(0, -radius * 1.75);
  context.bezierCurveTo(radius * 0.78, -radius * 0.48, radius, radius * 0.42, 0, radius);
  context.bezierCurveTo(-radius, radius * 0.42, -radius * 0.78, -radius * 0.48, 0, -radius * 1.75);
  context.fillStyle = "#020202";
  context.shadowColor = "rgba(0,0,0,.2)";
  context.shadowBlur = 10 * scale;
  context.fill();
  context.restore();
}

export default function InkGenesis({ onComplete }: InkGenesisProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const completeRef = useRef(onComplete);
  const closeTimerRef = useRef(0);
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    completeRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: false, desynchronized: true });
    if (!context) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let width = 1;
    let height = 1;
    let field = createInkField(window.innerWidth, window.innerHeight);
    let frameId = 0;
    let previousTime = performance.now();
    let simulationElapsed = reducedMotion ? 5.8 : 0;
    const startedAt = performance.now();

    const resize = () => {
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.35);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.max(1, Math.round(width * pixelRatio));
      canvas.height = Math.max(1, Math.round(height * pixelRatio));
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
      field = createInkField(width, height);
    };

    const finish = () => {
      setIsClosing(true);
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = window.setTimeout(() => completeRef.current(), 760);
    };

    const render = (now: number) => {
      const elapsed = reducedMotion ? 5.8 : (now - startedAt) / 1000;
      const delta = Math.min(0.034, Math.max(0.001, (now - previousTime) / 1000));
      previousTime = now;
      simulationElapsed = elapsed;
      context.fillStyle = "#fff";
      context.fillRect(0, 0, width, height);

      if (!reducedMotion && elapsed > 1.08) {
        stepInk(field, simulationElapsed, delta);
      }
      renderInkField(context, field, width, height, elapsed, reducedMotion);
      drawDroplet(
        context,
        width * 0.5,
        height * 0.49,
        Math.max(0.76, Math.min(1.3, Math.min(width, height) / 850)),
        elapsed,
      );

      if (!reducedMotion && elapsed < duration) frameId = window.requestAnimationFrame(render);
      else finish();
    };

    resize();
    window.addEventListener("resize", resize, { passive: true });
    frameId = window.requestAnimationFrame(render);
    return () => {
      window.cancelAnimationFrame(frameId);
      window.clearTimeout(closeTimerRef.current);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div className={`ink-genesis ${isClosing ? "is-closing" : ""}`} aria-label="一滴墨在水中晕开并生成水墨太极的开场动画">
      <canvas ref={canvasRef} aria-hidden="true" />
      <button className="genesis-skip" onClick={() => {
        setIsClosing(true);
        window.clearTimeout(closeTimerRef.current);
        closeTimerRef.current = window.setTimeout(() => completeRef.current(), 560);
      }}>
        跳过开场 <span aria-hidden="true">↗</span>
      </button>
      <p className="genesis-caption" aria-hidden="true">WUJI / ONE DROP / TEN THOUSAND FORMS</p>
    </div>
  );
}
