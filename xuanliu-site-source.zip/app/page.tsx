"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import FluidMark from "./experience/FluidMark";
import {
  defaultSiteContent,
  type Chapter,
  type SiteContent,
} from "./site-content";

const InkCanvas = dynamic(() => import("./experience/InkCanvas"), { ssr: false });
const InkGenesis = dynamic(() => import("./experience/InkGenesis"), { ssr: false });
const WuxingSigil = dynamic(() => import("./experience/WuxingSigil"), { ssr: false });

const storageKey = "xuanliu-content-v5";
const chapterStart = 0.15;
const chapterEnd = 0.78;
const humanLights = Array.from({ length: 28 }, (_, index) => ({
  x: 8 + ((index * 37) % 86),
  y: 58 + ((index * 19) % 35),
  size: 2 + ((index * 7) % 5),
  delay: (index % 8) * -0.42,
}));

type ExperiencePhase = "intro" | "chapters" | "outro";

function clamp(value: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function smoothstep(edge0: number, edge1: number, value: number) {
  const amount = clamp((value - edge0) / (edge1 - edge0));
  return amount * amount * (3 - 2 * amount);
}

function validateStoredContent(value: unknown): value is SiteContent {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<SiteContent>;
  return (
    typeof candidate.brand === "string" &&
    typeof candidate.heroTitle === "string" &&
    Array.isArray(candidate.chapters) &&
    candidate.chapters.length > 0 &&
    candidate.chapters.every((chapter) => chapter?.family === "five-arts" || chapter?.family === "platform")
  );
}

export default function Home() {
  const shellRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Array<HTMLElement | null>>([]);
  const spineNodeRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const targetProgressRef = useRef(0);
  const progressRef = useRef(0);
  const velocityRef = useRef(0);
  const pointerRef = useRef({ x: 0, y: 0, speed: 0, down: 0 });
  const genesisCompleteRef = useRef(false);
  const editorOpenRef = useRef(false);
  const editorAccessRef = useRef<HTMLButtonElement>(null);
  const editorCloseRef = useRef<HTMLButtonElement>(null);
  const editorPanelRef = useRef<HTMLElement>(null);
  const [content, setContent] = useState<SiteContent>(defaultSiteContent);
  const [contentReady, setContentReady] = useState(false);
  const [activeChapter, setActiveChapter] = useState(0);
  const [phase, setPhase] = useState<ExperiencePhase>("intro");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editorAccess, setEditorAccess] = useState(false);
  const [introComplete, setIntroComplete] = useState(false);

  useEffect(() => {
    const hydrateTimer = window.setTimeout(() => {
      try {
        const saved = window.localStorage.getItem(storageKey);
        if (saved) {
          const parsed: unknown = JSON.parse(saved);
          if (validateStoredContent(parsed)) setContent(parsed);
        }
      } catch {
        window.localStorage.removeItem(storageKey);
      }
      setEditorAccess(new URLSearchParams(window.location.search).get("edit") === "1");
      setContentReady(true);
    }, 0);
    return () => {
      window.clearTimeout(hydrateTimer);
    };
  }, []);

  useEffect(() => {
    if (!contentReady) return;
    window.localStorage.setItem(storageKey, JSON.stringify(content));
  }, [content, contentReady]);

  useEffect(() => {
    const wasOpen = editorOpenRef.current;
    editorOpenRef.current = editorOpen;
    document.documentElement.classList.toggle("has-editor", editorOpen);
    if (editorOpen) editorCloseRef.current?.focus();
    else if (wasOpen) editorAccessRef.current?.focus();
    return () => document.documentElement.classList.remove("has-editor");
  }, [editorOpen]);

  useEffect(() => {
    const shell = shellRef.current;
    if (!shell) return;

    const reducedMotionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    let reducedMotion = reducedMotionQuery.matches;
    let frameId = 0;
    let visualProgress = progressRef.current;
    let previousProgress = visualProgress;
    let previousTime = performance.now();
    let currentChapter = 0;
    let currentPhase: ExperiencePhase = "intro";
    let pointerTargetX = 0;
    let pointerTargetY = 0;
    let pointerSmoothX = 0;
    let pointerSmoothY = 0;
    let previousPointerX = window.innerWidth * 0.5;
    let previousPointerY = window.innerHeight * 0.5;
    let previousPointerTime = performance.now();
    let pointerSpeed = 0;
    let pointerDown = 0;
    let wheelImpulse = 0;
    let touchY: number | null = null;

    const onPointerMove = (event: PointerEvent) => {
      const now = performance.now();
      const elapsed = Math.max(now - previousPointerTime, 8);
      const distance = Math.hypot(event.clientX - previousPointerX, event.clientY - previousPointerY);
      pointerSpeed = Math.min(1, distance / elapsed / 1.25);
      pointerTargetX = clamp((event.clientX / window.innerWidth) * 2 - 1, -1, 1);
      pointerTargetY = clamp(1 - (event.clientY / window.innerHeight) * 2, -1, 1);
      previousPointerX = event.clientX;
      previousPointerY = event.clientY;
      previousPointerTime = now;
    };

    const onPointerDown = () => { pointerDown = 1; };
    const onPointerUp = () => { pointerDown = 0; };
    const onPointerLeave = () => {
      pointerTargetX = 0;
      pointerTargetY = 0;
      pointerDown = 0;
    };

    const onWheel = (event: WheelEvent) => {
      if (!genesisCompleteRef.current || editorOpenRef.current) return;
      event.preventDefault();
      const normalized = event.deltaY * (event.deltaMode === 1 ? 18 : event.deltaMode === 2 ? window.innerHeight : 1);
      targetProgressRef.current = clamp(targetProgressRef.current + normalized * 0.00032);
      wheelImpulse = clamp(wheelImpulse + normalized * 0.006, -10, 10);
    };

    const onTouchStart = (event: TouchEvent) => {
      touchY = event.touches[0]?.clientY ?? null;
    };
    const onTouchMove = (event: TouchEvent) => {
      if (!genesisCompleteRef.current || editorOpenRef.current || touchY === null || !event.touches[0]) return;
      event.preventDefault();
      const nextY = event.touches[0].clientY;
      const delta = touchY - nextY;
      touchY = nextY;
      targetProgressRef.current = clamp(targetProgressRef.current + delta * 0.00155);
      wheelImpulse = clamp(wheelImpulse + delta * 0.075, -8, 8);
    };
    const onTouchEnd = () => { touchY = null; };

    const onKeyDown = (event: KeyboardEvent) => {
      const element = event.target as HTMLElement | null;
      const editing = element?.matches("input, textarea, select, [contenteditable='true']");
      if (event.key === "Escape" && editorOpenRef.current) {
        setEditorOpen(false);
        return;
      }
      if (event.key === "Tab" && editorOpenRef.current) {
        const focusable = Array.from(
          editorPanelRef.current?.querySelectorAll<HTMLElement>(
            "button:not([disabled]), input:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex='-1'])",
          ) ?? [],
        ).filter((node) => node.offsetParent !== null);
        const first = focusable[0];
        const last = focusable.at(-1);
        if (first && last) {
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
          }
        }
        return;
      }
      if (editing || editorOpenRef.current) return;
      if (!genesisCompleteRef.current) return;
      if (editorAccess && event.key.toLowerCase() === "e") {
        setEditorOpen(true);
        return;
      }
      const steps: Record<string, number> = {
        ArrowDown: 0.045,
        PageDown: 0.13,
        " ": event.shiftKey ? -0.13 : 0.13,
        ArrowUp: -0.045,
        PageUp: -0.13,
      };
      if (event.key === "Home") {
        event.preventDefault();
        targetProgressRef.current = 0;
      } else if (event.key === "End") {
        event.preventDefault();
        targetProgressRef.current = 1;
      } else if (steps[event.key]) {
        event.preventDefault();
        targetProgressRef.current = clamp(targetProgressRef.current + steps[event.key]);
        wheelImpulse += Math.sign(steps[event.key]) * 2.5;
      }
    };

    const onMotionPreference = (event: MediaQueryListEvent) => {
      reducedMotion = event.matches;
    };

    const render = (now: number) => {
      const delta = Math.min(Math.max((now - previousTime) / 1000, 0.001), 0.08);
      previousTime = now;
      const progressEase = reducedMotion ? 1 : 1 - Math.exp(-delta * 4.35);
      const pointerEase = reducedMotion ? 1 : 1 - Math.exp(-delta * 8.5);
      visualProgress += (targetProgressRef.current - visualProgress) * progressEase;
      pointerSmoothX += (pointerTargetX - pointerSmoothX) * pointerEase;
      pointerSmoothY += (pointerTargetY - pointerSmoothY) * pointerEase;
      pointerSpeed *= Math.exp(-delta * 4.8);
      pointerDown += (0 - pointerDown) * (1 - Math.exp(-delta * 3.4));
      wheelImpulse *= Math.exp(-delta * 4.5);

      const progressVelocity = (visualProgress - previousProgress) / delta;
      previousProgress = visualProgress;
      const visualVelocity = clamp(progressVelocity * 9 + wheelImpulse * 0.32, -12, 12);
      progressRef.current = visualProgress;
      velocityRef.current = visualVelocity;
      pointerRef.current = {
        x: pointerSmoothX,
        y: pointerSmoothY,
        speed: pointerSpeed,
        down: pointerDown,
      };

      const chapterProgress = clamp((visualProgress - chapterStart) / (chapterEnd - chapterStart));
      const chapterFloat = chapterProgress * Math.max(content.chapters.length - 1, 0);
      const nextChapter = Math.round(chapterFloat);
      if (nextChapter !== currentChapter) {
        currentChapter = nextChapter;
        setActiveChapter(nextChapter);
      }

      const nextPhase: ExperiencePhase = visualProgress < 0.12 ? "intro" : visualProgress > 0.82 ? "outro" : "chapters";
      if (nextPhase !== currentPhase) {
        currentPhase = nextPhase;
        setPhase(nextPhase);
      }

      const introOpacity = 1 - smoothstep(0.065, 0.18, visualProgress);
      const chapterOpacity = smoothstep(0.09, 0.18, visualProgress) * (1 - smoothstep(0.78, 0.88, visualProgress));
      const outroOpacity = smoothstep(0.81, 0.92, visualProgress);
      const heroDissolve = smoothstep(0.05, 0.24, visualProgress);
      const spineReveal = smoothstep(0.10, 0.24, visualProgress) * (1 - smoothstep(0.81, 0.94, visualProgress));
      const earthReveal = smoothstep(0.94, 1, visualProgress);

      shell.style.setProperty("--intro-opacity", String(introOpacity));
      shell.style.setProperty("--chapter-opacity", String(chapterOpacity));
      shell.style.setProperty("--outro-opacity", String(outroOpacity));
      shell.style.setProperty("--journey", String(visualProgress));
      shell.style.setProperty("--chapter-journey", String(chapterProgress));
      shell.style.setProperty("--motion", String(Math.min(Math.abs(visualVelocity) / 5, 1)));
      shell.style.setProperty("--pointer-x", String(pointerSmoothX));
      shell.style.setProperty("--pointer-y", String(pointerSmoothY));
      shell.style.setProperty("--pointer-u", `${(pointerSmoothX + 1) * 50}%`);
      shell.style.setProperty("--pointer-v", `${(1 - pointerSmoothY) * 50}%`);
      shell.style.setProperty("--pointer-speed", String(pointerSpeed));
      shell.style.setProperty("--hero-dissolve", String(heroDissolve));
      shell.style.setProperty("--spine-reveal", String(spineReveal));
      shell.style.setProperty("--earth-reveal", String(earthReveal));
      shell.style.setProperty("--throne-presence", String(smoothstep(0.81, 0.92, visualProgress) * (1 - earthReveal * 0.32)));
      shell.style.setProperty("--spine-shift", `${(chapterProgress - 0.5) * -14}vh`);

      for (let index = 0; index < cardRefs.current.length; index += 1) {
        const card = cardRefs.current[index];
        if (!card) continue;
        const relative = index - chapterFloat;
        const distance = Math.abs(relative);
        const visible = distance < 1.7;
        card.dataset.visible = visible ? "true" : "false";
        if (!visible) {
          card.style.setProperty("--card-opacity", "0");
          card.dataset.active = "false";
          continue;
        }
        const activeWeight = 1 - clamp(distance, 0, 1);
        const x = relative * 31;
        const y = Math.abs(relative) * 8 + relative * 4.5;
        const z = -distance * 240;
        const scale = Math.max(0.68, 1 - distance * 0.17);
        const opacity = clamp(1 - distance * 0.62);
        card.style.setProperty("--card-x", `${x}vw`);
        card.style.setProperty("--card-y", `${y}vh`);
        card.style.setProperty("--card-z", `${z}px`);
        card.style.setProperty("--card-scale", String(scale));
        card.style.setProperty("--card-opacity", String(opacity));
        card.style.setProperty("--card-blur", "0px");
        card.style.setProperty("--card-ry", `${relative * -12 + pointerSmoothX * 3.5 * activeWeight}deg`);
        card.style.setProperty("--card-rx", `${pointerSmoothY * -3.2 * activeWeight}deg`);
        card.style.setProperty("--card-rz", `${relative * 2.6}deg`);
        card.style.setProperty("--card-active", String(activeWeight));
        card.style.zIndex = String(30 - Math.round(distance * 5));
        card.dataset.active = distance < 0.5 ? "true" : "false";
      }

      for (let index = 0; index < spineNodeRefs.current.length; index += 1) {
        const node = spineNodeRefs.current[index];
        if (!node) continue;
        const relative = index - chapterFloat;
        const distance = Math.abs(relative);
        node.style.setProperty("--node-y", `${relative * 13.5}vh`);
        node.style.setProperty("--node-scale", String(Math.max(0.52, 1 - distance * 0.18)));
        node.style.setProperty("--node-opacity", String(clamp(1 - distance * 0.25, 0.12, 1)));
        node.style.setProperty("--node-active", String(1 - clamp(distance)));
      }

      frameId = window.requestAnimationFrame(render);
    };

    window.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("pointerdown", onPointerDown, { passive: true });
    window.addEventListener("pointerup", onPointerUp, { passive: true });
    document.documentElement.addEventListener("mouseleave", onPointerLeave, { passive: true });
    window.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchmove", onTouchMove, { passive: false });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    window.addEventListener("keydown", onKeyDown);
    reducedMotionQuery.addEventListener("change", onMotionPreference);
    frameId = window.requestAnimationFrame(render);

    return () => {
      window.cancelAnimationFrame(frameId);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointerup", onPointerUp);
      document.documentElement.removeEventListener("mouseleave", onPointerLeave);
      window.removeEventListener("wheel", onWheel);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("touchend", onTouchEnd);
      window.removeEventListener("keydown", onKeyDown);
      reducedMotionQuery.removeEventListener("change", onMotionPreference);
    };
  }, [content.chapters.length, editorAccess]);

  const moveToProgress = useCallback((progress: number) => {
    targetProgressRef.current = clamp(progress);
  }, []);

  const completeGenesis = useCallback(() => {
    genesisCompleteRef.current = true;
    setIntroComplete(true);
  }, []);

  const moveToChapter = useCallback((index: number) => {
    const denominator = Math.max(content.chapters.length - 1, 1);
    moveToProgress(chapterStart + (clamp(index, 0, content.chapters.length - 1) / denominator) * (chapterEnd - chapterStart));
  }, [content.chapters.length, moveToProgress]);

  const updateChapter = (id: string, patch: Partial<Chapter>) => {
    setContent((current) => ({
      ...current,
      chapters: current.chapters.map((chapter) => chapter.id === id ? { ...chapter, ...patch } : chapter),
    }));
  };

  const nextChapter = () => moveToChapter(Math.min(activeChapter + 1, content.chapters.length - 1));
  const previousChapter = () => moveToChapter(Math.max(activeChapter - 1, 0));
  const current = content.chapters[activeChapter] ?? content.chapters[0];

  return (
    <main id="experience" className={`site ${contentReady ? "is-ready" : ""} ${introComplete ? "is-genesis-complete" : ""}`}>
      <a className="skip-link" href="#hero-title">跳至主标题</a>
      {!introComplete ? <InkGenesis onComplete={completeGenesis} /> : null}
      <div ref={shellRef} className={`experience-shell phase-${phase}`}>
        <InkCanvas className="ink-canvas" progressRef={progressRef} velocityRef={velocityRef} pointerRef={pointerRef} />
        <div className="ink-fallback" aria-hidden="true" />

        <div className="hero-visual" aria-hidden="true">
          <div className="hero-taiji-art" />
          <span className="hero-orbit orbit-one" />
          <span className="hero-orbit orbit-two" />
          <span className="hero-depth-flare" />
        </div>

        <div className="spine-visual" aria-hidden="true">
          <div className="spine-art">
            <span className="meridian-thread" />
            {content.chapters.map((chapter, index) => (
              <span
                ref={(node) => { spineNodeRefs.current[index] = node; }}
                className="meridian-node"
                data-family={chapter.family}
                key={chapter.id}
                style={{ "--node-accent": chapter.accent } as CSSProperties}
              >
                <i /><b>{chapter.glyph}</b><small>{chapter.number}</small>
              </span>
            ))}
          </div>
          <span className="meridian-aura" />
        </div>

        <div className="finale-visual" role="img" aria-label={content.finaleImageAlt}>
          <div className="finale-throne" style={{ backgroundImage: `url(${content.finaleImage})` }} />
          <div className="finale-hand-light" aria-hidden="true" />
          {phase === "outro" ? <WuxingSigil progressRef={progressRef} pointerRef={pointerRef} /> : null}
          <div className="finale-mist" aria-hidden="true" />
        </div>

        <div className="human-realm" aria-hidden="true">
          <div className="human-horizon" />
          {humanLights.map((light, index) => (
            <i
              key={index}
              style={{
                "--human-x": `${light.x}%`,
                "--human-y": `${light.y}%`,
                "--human-size": `${light.size}px`,
                "--human-delay": `${light.delay}s`,
              } as CSSProperties}
            />
          ))}
        </div>

        <div className="pointer-light" aria-hidden="true" />
        <div className="screen-grain" aria-hidden="true" />
        <div className="edge-vignette" aria-hidden="true" />

        <header className="site-header">
          <button className="brand-lockup" onClick={() => moveToProgress(0)} data-cursor="link" aria-label="返回开场">
            <strong>{content.brand}</strong>
            <span>{content.brandLatin}</span>
          </button>

          <div className="nav-stack">
            <nav className="nav-pill" aria-label="主导航">
              <button onClick={() => moveToChapter(0)} data-cursor="link">五术</button>
              <FluidMark pointerRef={pointerRef} />
              <button onClick={() => moveToProgress(1)} data-cursor="link">人间</button>
            </nav>
            <div className="chapter-counter" aria-live="polite">
              <button onClick={previousChapter} data-cursor="link" aria-label="上一章">&lt;&lt;</button>
              <p key={current?.id}><span>{current?.number}</span> / {current?.latin}</p>
              <button onClick={nextChapter} data-cursor="link" aria-label="下一章">&gt;&gt;</button>
            </div>
          </div>
        </header>

        {editorAccess ? (
          <button ref={editorAccessRef} className="editor-access" onClick={() => setEditorOpen(true)} data-cursor="link">
            CONFIG / E
          </button>
        ) : null}

        <section className="hero-overlay" aria-labelledby="hero-title" aria-hidden={phase !== "intro"} inert={phase !== "intro"}>
          <p className="hero-kicker">{content.kicker}</p>
          <div className="hero-heading-wrap">
            <h1 id="hero-title" tabIndex={-1}>{content.heroTitle}</h1>
            <p className="hero-latin">{content.heroLatin}</p>
          </div>
          <p className="hero-introduction">{content.introduction}</p>
          <button className="explore-button" onClick={() => moveToChapter(0)} data-cursor="link">
            <span>入境</span><i aria-hidden="true">↓</i>
          </button>
          <p className="scroll-caption"><span /> SCROLL / DRAG TO FOLLOW THE MERIDIAN</p>
        </section>

        <section className="chapter-interface" aria-label="国学篇章" aria-hidden={phase !== "chapters"} inert={phase !== "chapters"}>
          <div className="chapter-index">
            <p>天枢节点</p>
            <ol>
              {content.chapters.map((chapter, index) => (
                <li key={chapter.id} className={index === activeChapter ? "is-active" : ""}>
                  <button onClick={() => moveToChapter(index)} data-cursor="link" aria-label={`前往第 ${chapter.number} 章：${chapter.title}`}>
                    <span>{chapter.number}</span><strong>{chapter.glyph}</strong>
                  </button>
                </li>
              ))}
            </ol>
          </div>

          <div className="card-stage">
            {content.chapters.map((chapter, index) => (
              <article
                ref={(node) => { cardRefs.current[index] = node; }}
                className="chapter-card"
                data-chapter={chapter.id}
                data-active={index === 0 ? "true" : "false"}
                key={chapter.id}
                style={{ "--chapter-accent": chapter.accent } as CSSProperties}
                aria-hidden={index !== activeChapter}
                inert={index !== activeChapter}
              >
                <div
                  className="chapter-media"
                  role="img"
                  aria-label={chapter.mediaAlt}
                  style={{ backgroundImage: `url(${chapter.media})`, backgroundPosition: chapter.imagePosition }}
                />
                <div className="media-wash" aria-hidden="true" />
                <div className="card-pointer-glow" aria-hidden="true" />
                <div className="card-coordinate">GATE {chapter.number} / {String(content.chapters.length).padStart(2, "0")}</div>
                <div className="card-glyph" aria-hidden="true">{chapter.glyph}</div>
                <div className="card-copy">
                  <p>{chapter.eyebrow}</p><h2>{chapter.title}</h2><span>{chapter.latin}</span>
                </div>
                <button className="card-advance" onClick={nextChapter} data-cursor="view" aria-label={`阅览下一章，当前：${chapter.title}`} />
              </article>
            ))}
          </div>

          <article className="chapter-detail" key={current?.id}>
            <p className="detail-label">CURRENT THOUGHT</p>
            <blockquote>{current?.quote}</blockquote>
            <p>{current?.summary}</p>
          </article>
        </section>

        <section className="outro" aria-labelledby="contact-title" aria-hidden={phase !== "outro"} inert={phase !== "outro"}>
          <div className="outro-copy">
            <p className="outro-kicker">BENEATH THE EMPTY THRONE / 人间</p>
            <h2 id="contact-title">{content.contactTitle}</h2>
            <p>{content.contactCopy}</p>
            <p className="outro-philosophy">{content.finaleKicker}</p>
          </div>
          <nav className="realm-gates" aria-label="山医命卜相入口">
            {content.chapters.slice(0, 5).map((chapter, index) => (
              <button key={chapter.id} onClick={() => moveToChapter(index)}><span>{chapter.glyph}</span><small>{chapter.latin}</small></button>
            ))}
          </nav>
          <div className="realm-satellites" aria-label="平台能力">
            {content.chapters.slice(5).map((chapter, index) => (
              <button key={chapter.id} onClick={() => moveToChapter(index + 5)}>{chapter.glyph} / {chapter.title}</button>
            ))}
          </div>
          <a className="contact-link" href={`mailto:${content.contactEmail}`} data-cursor="link">
            <span>共同建造</span><strong>{content.contactEmail}</strong><i aria-hidden="true">↗</i>
          </a>
          <button className="return-button" onClick={() => moveToProgress(0)} data-cursor="link">回到无极 ↑</button>
        </section>

        <div className="journey-meter" aria-hidden="true"><span /></div>
      </div>

      <div id="accessible-content" className="semantic-content sr-only">
        <h2>玄流国学篇章</h2>
        {content.chapters.map((chapter) => (
          <section key={chapter.id}><h3>{chapter.glyph} · {chapter.title}</h3><p>{chapter.summary}</p></section>
        ))}
      </div>

      {editorOpen ? (
        <>
          <button className="editor-backdrop" onClick={() => setEditorOpen(false)} aria-label="关闭内容编辑器" />
          <aside ref={editorPanelRef} className="content-editor" role="dialog" aria-modal="true" aria-labelledby="editor-title">
            <header>
              <div><p>CONTENT SYSTEM</p><h2 id="editor-title">内容控制</h2></div>
              <button ref={editorCloseRef} onClick={() => setEditorOpen(false)} aria-label="关闭内容编辑器">×</button>
            </header>
            <p className="editor-help">这里的修改只用于即时预览并保存在当前浏览器；正式内容集中在 <code>app/site-content.ts</code>。</p>
            <label>品牌名<input name="brand" autoComplete="off" value={content.brand} onChange={(event) => setContent({ ...content, brand: event.target.value })} /></label>
            <label>首屏标题<input name="heroTitle" autoComplete="off" value={content.heroTitle} onChange={(event) => setContent({ ...content, heroTitle: event.target.value })} /></label>
            <label>首屏说明<textarea name="introduction" autoComplete="off" value={content.introduction} onChange={(event) => setContent({ ...content, introduction: event.target.value })} /></label>
            <label>终章王座图片<input name="finaleImage" type="url" autoComplete="off" value={content.finaleImage} onChange={(event) => setContent({ ...content, finaleImage: event.target.value })} /></label>
            <div className="editor-chapters">
              {content.chapters.map((chapter) => (
                <fieldset key={chapter.id}>
                  <legend>{chapter.number} / {chapter.glyph}</legend>
                  <label>标题<input name={`${chapter.id}-title`} autoComplete="off" value={chapter.title} onChange={(event) => updateChapter(chapter.id, { title: event.target.value })} /></label>
                  <label>简介<textarea name={`${chapter.id}-summary`} autoComplete="off" value={chapter.summary} onChange={(event) => updateChapter(chapter.id, { summary: event.target.value })} /></label>
                  <label>图片路径或 URL<input name={`${chapter.id}-media`} type="url" autoComplete="off" value={chapter.media} onChange={(event) => updateChapter(chapter.id, { media: event.target.value })} /></label>
                </fieldset>
              ))}
            </div>
            <footer>
              <button onClick={() => setContent(defaultSiteContent)}>恢复默认内容</button>
              <button className="editor-done" onClick={() => setEditorOpen(false)}>完成预览</button>
            </footer>
          </aside>
        </>
      ) : null}
    </main>
  );
}
