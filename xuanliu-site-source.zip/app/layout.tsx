import type { Metadata, Viewport } from "next";
import "./globals.css";

export const viewport: Viewport = {
  themeColor: "#010606",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  metadataBase: new URL("https://luma-editable-studio.rr7jp4d56w.chatgpt.site"),
  title: "玄流 XUANLIU — 一墨生万象",
  description: "一场以水墨太极、天枢玉脉与空王座构成的国学数字体验，连接山医命卜相、同道、古籍与周期研究。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  openGraph: {
    title: "玄流 XUANLIU — 一墨生万象",
    description: "沿天枢玉脉穿行，让山医命卜相、同道、古籍与周期研究在光中显影。",
    type: "website",
    locale: "zh_CN",
    images: [{ url: "/og.jpg", width: 1672, height: 941, alt: "玄流空王座与水墨太极数字体验" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "玄流 XUANLIU — 一墨生万象",
    description: "水墨太极、天枢玉脉与空王座构成的国学数字体验。",
    images: ["/og.jpg"],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
