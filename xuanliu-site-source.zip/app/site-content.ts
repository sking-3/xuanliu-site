/**
 * 站点内容的唯一入口。
 *
 * 想换标题、篇章、图片或颜色时，只需要修改这个文件；滚动、WebGL 和版式
 * 都会继续复用。需要即时预览时，在网址后加 `?edit=1` 打开内容控制入口。
 */
export type Chapter = {
  id: string;
  number: string;
  glyph: string;
  family: "five-arts" | "platform";
  title: string;
  latin: string;
  eyebrow: string;
  summary: string;
  quote: string;
  media: string;
  mediaAlt: string;
  imagePosition: string;
  accent: string;
};

export type SiteContent = {
  brand: string;
  brandLatin: string;
  kicker: string;
  heroTitle: string;
  heroLatin: string;
  introduction: string;
  chapters: Chapter[];
  contactTitle: string;
  contactCopy: string;
  contactEmail: string;
  finaleImage: string;
  finaleImageAlt: string;
  finaleKicker: string;
};

// Vite will set BASE_URL to the repository path when this project is deployed
// through GitHub Pages. Keeping every local asset behind this helper lets the
// same content file work on the Sites domain, localhost and GitHub Pages.
const asset = (file: string) => `${import.meta.env.BASE_URL}${file}`;
const conceptImage = asset("ink-taiji-concept.png");
const spineImage = asset("og.png");

export const defaultSiteContent: SiteContent = {
  brand: "玄流",
  brandLatin: "XUANLIU",
  kicker: "山 · 医 · 命 · 卜 · 相 / 同道 · 藏经 · 观潮",
  heroTitle: "一墨生万象",
  heroLatin: "ONE INK, TEN THOUSAND FORMS",
  introduction:
    "从无极的一粒墨出发，沿天枢玉脉穿行。五术、同道、古籍与周期在光中显影，最终归于人间。",
  chapters: [
    {
      id: "shan",
      number: "01",
      glyph: "山",
      family: "five-arts",
      title: "养气入山",
      latin: "CULTIVATION",
      eyebrow: "FIVE ARTS / 山",
      summary: "从呼吸、静观与日常修习开始，让身体重新感知时间、节律与自身边界。",
      quote: "虚静恬淡，寂寞无为。",
      media: conceptImage,
      mediaAlt: "淡墨云气在青黛山脉之间缓慢流动",
      imagePosition: "42% 24%",
      accent: "#729579",
    },
    {
      id: "yi",
      number: "02",
      glyph: "医",
      family: "five-arts",
      title: "岐黄知身",
      latin: "HEALING",
      eyebrow: "FIVE ARTS / 医",
      summary: "以传统医学文献、节气与生活方式为学习入口，理解身体如何与环境共同变化。",
      quote: "上工治未病，不治已病。",
      media: spineImage,
      mediaAlt: "药气、铜针和脉络在朱砂色光中显影",
      imagePosition: "20% 46%",
      accent: "#a85f51",
    },
    {
      id: "ming",
      number: "03",
      glyph: "命",
      family: "five-arts",
      title: "星命成盘",
      latin: "DESTINY",
      eyebrow: "FIVE ARTS / 命",
      summary: "以八字、紫微与历法为结构，把排盘变成可以回看、比较和持续学习的个人玄册。",
      quote: "仰以观于天文，俯以察于地理。",
      media: conceptImage,
      mediaAlt: "星图、命轮与金色刻度在墨色空间中汇聚",
      imagePosition: "76% 52%",
      accent: "#b49a69",
    },
    {
      id: "bu",
      number: "04",
      glyph: "卜",
      family: "five-arts",
      title: "一卦问机",
      latin: "DIVINATION",
      eyebrow: "FIVE ARTS / 卜",
      summary: "从六爻、梅花到奇门，以清楚的过程记录起卦条件、判断依据与事后复盘。",
      quote: "极数知来之谓占。",
      media: spineImage,
      mediaAlt: "龟甲裂纹与蓍草在靛青色颗粒中展开",
      imagePosition: "34% 70%",
      accent: "#587e91",
    },
    {
      id: "xiang",
      number: "05",
      glyph: "相",
      family: "five-arts",
      title: "观形察势",
      latin: "FORM & FIELD",
      eyebrow: "FIVE ARTS / 相",
      summary: "从形貌、空间与地势理解相法，把观察转化为尊重边界、避免武断的学习过程。",
      quote: "有诸内，必形诸外。",
      media: conceptImage,
      mediaAlt: "铜镜、罗盘与地势等高线在银白墨痕中浮现",
      imagePosition: "63% 28%",
      accent: "#c1c8c0",
    },
    {
      id: "circle",
      number: "06",
      glyph: "同",
      family: "platform",
      title: "以术会友",
      latin: "CIRCLE",
      eyebrow: "XUANLIU / 同道",
      summary: "从共同兴趣、学习方向和公开玄册出发，建立克制、可选择、尊重隐私的同道关系。",
      quote: "同声相应，同气相求。",
      media: spineImage,
      mediaAlt: "多条微光关系线在深色空间中彼此靠近",
      imagePosition: "56% 82%",
      accent: "#9f86a7",
    },
    {
      id: "archive",
      number: "07",
      glyph: "藏",
      family: "platform",
      title: "古籍新读",
      latin: "ARCHIVE",
      eyebrow: "XUANLIU / 藏经",
      summary: "汇集原文、注释、版本线索与个人笔记，让玄学文献可以查证、串联并形成学习路径。",
      quote: "学而不思则罔，思而不学则殆。",
      media: conceptImage,
      mediaAlt: "竹简文字与索引节点在纸墨之间层层展开",
      imagePosition: "18% 55%",
      accent: "#a99a78",
    },
    {
      id: "market",
      number: "08",
      glyph: "潮",
      family: "platform",
      title: "观象知周期",
      latin: "CYCLES",
      eyebrow: "XUANLIU / 观潮",
      summary: "以文化、历法与周期为研究视角理解市场叙事；保留证据、复盘与风险边界，不替代投资判断。",
      quote: "日往则月来，月往则日来。",
      media: spineImage,
      mediaAlt: "市场周期曲线与潮汐颗粒在青金色空间中交叠",
      imagePosition: "82% 42%",
      accent: "#718f82",
    },
  ],
  contactTitle: "位可虚，道在人间。",
  contactCopy: "王座有尽，众生无穷。山医命卜相，由每个人的选择重新发生。",
  contactEmail: "studio@example.com",
  finaleImage: asset("qin-empty-throne-v3.jpg"),
  finaleImageAlt: "秦制黑漆青铜青龙空王座悬于暗殿，冠旒、袍袖、垂手与掌中水墨太极只在交互中短暂显形",
  finaleKicker: "EMPTY THRONE / HUMAN REALM · 无极生太极，太极归众生",
};
