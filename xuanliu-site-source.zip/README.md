# 玄流 XUANLIU

一套可编辑的国学 × 未来金融沉浸式网站。交互语言参考高端 WebGL 工作室网站，但品牌、文案、水墨太极、秦制空王座与全部视觉资产均为本项目原创实现。

## 运行

需要 Node.js `>=22.13.0`。

```bash
npm install
npm run dev
```

打开终端给出的本地地址。发布前执行：

```bash
npm run lint
npm test
```

## 放到 GitHub 后直接对外访问

本项目已经包含 GitHub Pages 自动发布配置。创建一个**公开** GitHub 仓库后，把这个项目的全部文件推送到 `main` 分支；GitHub 会自动构建完整的交互版网站，并在仓库的 **Settings → Pages** 显示访问网址。

不需要改代码，也不需要把构建产物上传到仓库。以后每次修改 `app/site-content.ts` 或任意页面文件并推送，公开网站会自动更新。

如果你想在自己的电脑上预览 GitHub Pages 版，运行：

```bash
npm run build:pages
npm run preview:pages
```

GitHub Pages 是纯前端运行环境；目前的水墨、鼠标、滚轮、编辑预览和章节交互都可以运行。未来要加入登录、排盘存档、交友资料或金融数据时，应部署到支持数据库和服务端的 Sites/Cloudflare/Vercel；页面与内容层不需要重写。

## 最常修改的内容

所有正式文案、章节、图片路径与颜色集中在：

- `app/site-content.ts`

每个章节都标有这些字段：

- `glyph`：单字图标。
- `title` / `latin`：中英文标题。
- `summary` / `quote`：简介与引文。
- `media` / `mediaAlt`：图片地址与无障碍描述。
- `imagePosition`：图片裁切焦点，例如 `50% 40%`。
- `accent`：章节强调色。

把新图片放进 `public/`，然后把 `media` 改成 `/你的图片.jpg`。终章王座由 `finaleImage` 控制，联系邮箱由 `contactEmail` 控制。

临时预览时，在网址后加 `?edit=1`，点击右侧 `CONFIG / E`。修改会保存在当前浏览器；需要永久生效时，把最终内容同步回 `app/site-content.ts`。

## 动画与框架分工

| 文件 / 技术 | 作用 | 常用调整 |
| --- | --- | --- |
| `app/experience/InkGenesis.tsx` · Canvas 2D | 白场、墨滴、墨晕、旋转颗粒与太极显形的 7.1 秒开场 | `duration`、墨滴时间、水墨粒子数量 |
| `app/experience/InkCanvas.tsx` · WebGL 2 | 全程 GPU 水墨体积、颗粒、光束、鼠标扰动和滚轮能量 | Fragment Shader 的颜色、密度、光照 |
| `app/experience/FluidMark.tsx` · Canvas 2D | 右上导航中会追随鼠标的流体标志 | 线条数量、弹性、发光强度 |
| `app/experience/WuxingSigil.tsx` · Canvas 2D | 终章秦始皇冕冠/袍影/垂手墨迹，以及掌中太极、五行轨道 | 显形区间、手掌坐标、五行颜色 |
| `app/page.tsx` · React / TypeScript | 虚拟滚动时间轴、章节状态、鼠标/触控/键盘、内容编辑器 | `chapterStart`、`chapterEnd`、滚轮系数 |
| `github-pages/` + `.github/workflows/` · Vite / GitHub Actions | GitHub Pages 的纯前端发布入口；复用同一套网站组件与内容 | 一般不需要改；推送 `main` 自动发布 |
| `app/globals.css` · CSS | 单屏摄影机式布局、卡片透视、响应式、安全区、焦点和降级动画 | 尺寸、排版、断点、透明度 |
| `app/site-content.ts` · 数据层 | 所有可替换内容的唯一正式来源 | 文案、图片、数字、颜色、邮箱 |

## 终章设计逻辑

王座的实体状态保持为空，代表“位置、权力、潜能与尚未决定的未来”，可以同时承接玄学与金融叙事。秦始皇不以写实人物常驻，而是在滚动抵达末端后以水墨冕冠和垂手短暂显形；鼠标靠近手掌时，太极与木火土金水增强，移开后重新隐入殿中。

这种结构以后可以自然替换解释：

- 玄学：无极、太极、五行、气运。
- 金融：周期、流动性、轮动、风险与秩序。

## 交互

- 滚轮 / 触控上滑：推进虚拟镜头。
- 上下方向键、Page Up / Page Down、Home / End：键盘导航。
- 鼠标移动：粒子视差、光场和卡片倾斜。
- 鼠标靠近终章手掌：增强太极与五行显形。
- `prefers-reduced-motion`：自动缩短或关闭非必要运动。
- `?edit=1`：打开内容预览入口。

## 资源建议

- 主视觉：16:9，至少 1920×1080，WebP/JPEG，单张尽量低于 700 KB。
- 透明纹理：PNG/WebP，避免烘焙文字和水印。
- 视频：H.264 MP4 + WebM，6–12 秒无缝循环、无水印、静音，桌面建议低于 8 MB。
- 3D 模型：glTF/GLB，独立提供贴图；本版无需模型即可运行。

不要直接使用带水印素材。替换第三方内容前应确认授权；本项目没有通过裁切或覆盖方式移除水印。

## 技术栈

- Next.js 16 + React 19 + TypeScript
- vinext / Vite 构建
- 原生 WebGL 2 与 Canvas 2D；无运行时 AI、无外部动画服务
- CSS 自适应布局与本地 `localStorage` 编辑预览

设计原则是“DOM 负责内容与可访问性，GPU/Canvas 负责氛围与连续运动”，因此文案始终可编辑、可索引，视觉层也能独立替换。
