import assert from "node:assert/strict";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("server-renders the Xuanliu experience and metadata", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<html lang="zh-CN">/);
  assert.match(html, /<title>玄流 XUANLIU — 一墨生万象<\/title>/);
  assert.match(html, /一场以水墨太极、天枢玉脉与空王座构成的国学数字体验/);
  assert.match(html, /一墨生万象/);
  assert.match(html, /天枢节点/);
  assert.match(html, /山医命卜相/);
  assert.match(html, /观象知周期/);
  assert.match(html, /位可虚，道在人间/);
  assert.match(html, /\/og\.png/);
});
